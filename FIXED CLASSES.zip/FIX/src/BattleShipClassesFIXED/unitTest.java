package BattleShipClassesNEEDSFIXING;
import org.junit.*; 
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class unitTest {
    Player TestPlayer = new Player();
	@Test
	void test() {
	  assertTrue(condition);
	}

}
