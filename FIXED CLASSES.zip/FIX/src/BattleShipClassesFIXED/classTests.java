/**
 * 
 */
package BattleShipClassesNEEDSFIXING;

/**
 * @author User
 *
 */
public class classTests {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	
	}

}
